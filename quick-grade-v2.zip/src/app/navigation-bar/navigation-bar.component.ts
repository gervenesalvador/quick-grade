import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from '@angular/fire/firestore';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { User } from '../model/user'

@Component({
  selector: 'app-navigation-bar',
  templateUrl: './navigation-bar.component.html',
  styleUrls: ['./navigation-bar.component.css']
})
export class NavigationBarComponent implements OnInit {
  @Input() user_id: any;
  usersCollection: AngularFirestoreCollection<User>;
  userDoc: AngularFirestoreDocument<User>;
  user: Observable<User>;

  constructor(
    private afs: AngularFirestore, 
    private router: Router
  ) {

  }

  ngOnInit() {
    if (!this.user_id) {
      sessionStorage.setItem('alertMessage', JSON.stringify({message: "No User Selected"}));
      this.router.navigateByUrl('/users');
    }
    
    this.usersCollection = this.afs.collection<User>('Users');
    this.userDoc = this.usersCollection.doc(this.user_id);
    this.user = this.userDoc.valueChanges();
  }

}
