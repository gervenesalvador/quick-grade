import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from '@angular/fire/firestore';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { User } from '../model/user';
import * as jspdf from 'jspdf'; 
import html2canvas from 'html2canvas'; 
import { DragulaService } from 'ng2-dragula';

@Component({
  selector: 'app-template',
  templateUrl: './template.component.html',
  styleUrls: ['./template.component.css']
})
export class TemplateComponent implements OnInit {
  @Input() exam_items: string;
  list: Array<any> = [];
  aa: any;
  image: string;

  user_id: string;
  usersCollection: AngularFirestoreCollection<User>;
  userDoc: AngularFirestoreDocument<User>;
  user: Observable<User>;
  constructor(private route: ActivatedRoute, private dragulaService: DragulaService) { 
    this.user_id = this.route.snapshot.paramMap.get('id');
     dragulaService.createGroup('COPYABLE', {
      copy: (el, source) => {
        return source.id === 'type_container';
      },
      accepts: (el, target, source, sibling) => {
        // To avoid dragging from right to type_container container
        return target.id !== 'type_container';
      }
    });
  }

  ngOnInit() {
    this.list.push({
      id: 20,
      keys: [
        { top: "520px", left: "557px"},
        { top: "520px", left: "688px"}
      ]
    });

    this.list.push({
      id: 30,
      keys: [
        { top: "671px", left: "470px" },
        { top: "426px", left: "655px" },
        { top: "671px", left: "655px" },
      ]
    });

    this.list.push({
      id: 50,
      keys: [
        { top: "677px", left: "423px" },
        { top: "431px", left: "554px" },
        { top: "677px", left: "554px" },
        { top: "431px", left: "686px" },
        { top: "677px", left: "686px" },
      ]
    });

    this.aa = this.list[0].keys;
    this.image = "/assets/images/"+this.list[0].id+".jpg" ;
    console.log(this.aa);
  }

  generate(): void {
    let draggable = document.getElementsByClassName("type_container_draggable");
    for (let i = 0; i < draggable.length; i++) {
      let left = draggable[i]['style'].left;
      draggable[i]['style'].left = (+(left.replace("px", "")) + 7).toString() + "px";
    }
    
    var data = document.getElementById('paper'); 
    html2canvas(data).then(canvas => { 
      var imgWidth = 208; 
      var pageHeight = 295; 
      var imgHeight = canvas.height * imgWidth / canvas.width; 
      var heightLeft = imgHeight; 

      const contentDataURL = canvas.toDataURL('image/png') 
      let pdf = new jspdf('p', 'mm', 'a4'); // A4 size page of PDF 
      var position = 0; 
      pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight) 

      let draggable = document.getElementsByClassName("type_container_draggable");
      for (let i = 0; i < draggable.length; i++) {
        let left = draggable[i]['style'].left;
        draggable[i]['style'].left = (+(left.replace("px", "")) - 7).toString() + "px";
      }
      pdf.save('template.pdf'); // Generated PDF  
    }); 
  }

  change_exam(item) {
    // console.log(this.list[item]);
    this.aa = this.list[item].keys;
    this.image = "/assets/images/"+this.list[item].id+".jpg" ;
  }
}
