import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from '@angular/fire/firestore';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { User } from '../model/user';
import { Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
	usersCollection: AngularFirestoreCollection<User>;
  @ViewChild('alert') alert: ElementRef;
  alert_message = "";
	userForm = new FormGroup({
		email: new FormControl(''),
		password: new FormControl(''),
	});
  constructor(
  	private afs: AngularFirestore,
  	private router: Router
  ) { }

  ngOnInit() {
  	this.alert.nativeElement.classList.remove('show');
  	this.alert.nativeElement.style.display = 'none';
  }

  login() :void {
  	let data = this.userForm.value;
  	this.usersCollection = this.afs.collection<User>('Users', ref => ref.where('email', '==', data.email));
		this.usersCollection.snapshotChanges().map(user => {
			return user.map(user_data => {
				return { id: user_data.payload.doc.id, ...user_data.payload.doc.data() };
			});
		}).subscribe(user => {
			if (user[0].id) {
        this.router.navigateByUrl("/users/"+user[0].id+"/classes");
			} else {
				this.userForm.reset();
				this.showAlert("Email not found");
			}
			
		});
  }

  closeAlert() {
  	this.alert_message = "";
    this.alert.nativeElement.classList.remove('show');
    this.alert.nativeElement.style.display = 'none';
  }

  showAlert(message) {
  	this.alert_message = message;
  	this.alert.nativeElement.classList.add('show');
    this.alert.nativeElement.style.display = 'block';
  }
}
