// import { Section } from './section';

export interface User {
	id: string;
	// Classes: Section;
	email: string;
}