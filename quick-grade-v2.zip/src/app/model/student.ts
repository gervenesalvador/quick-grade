export interface Student {
	classes: [string];
	customID: string;
	exams: [string];
	firstName: string;
	lastName: string;
}