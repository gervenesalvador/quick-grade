export const environment = {
  production: true,

  firebaseConfig: {
  	apiKey: 'AIzaSyDOZy-SG8f9hSoM2CY_PtiUtjsYXzzM9k8',
    authDomain: 'quickgrade-26cde.firebaseapp.com',
    databaseURL: 'https://quickgrade-26cde.firebaseio.com',
    projectId: 'quickgrade-26cde',
    storageBucket: 'quickgrade-26cde.appspot.com',
    messagingSenderId: '168163613333',
  }
};
